<script>
		// JavaScript Document
window.addEventListener('DOMContentLoaded',
function(){ 
	if(navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(
		function(pos) {
			var gmap = new google.maps.Map(
			document.querySelector('#gmap'),
			{
				Zoom: 14,
				center: new google.maps.LatLng(
				pos.coords.latitude,pos.coords.longitude
				),
				mapTypeId: google.maps.MapTypeId.ROADMAP
			}
			);
		},
		function(err) {
			var msgs = [
			  err.message,
			  'Permission denied.',
			  'Position unavailable.',
			  'Timeout.'
			  ];
			  alert(msgs[err.code]);
		},
		{
			timeout : 10000,
			maximunAge : 0,
			enableHighAccuracy: true
		}
		);
	} else {
		alert("Your browser doesn't support the Geolocation API.");
	}
},
false
);

//FORM VALIDATION//
function val(){
	var name=document.getElementsByName("name")[0].value;
	if(name.length<3){
		alert("Error:Invalid name,Enter atleast 3 characters");
		return false;
	}
	
	var telnum=document.getElementsByName("telnum")[0].value;
	if(telnum.length<10 || isNaN(telnum)){
		alert("Error:Enter valid number");
		return false;
	}
			
	var email=document.getElementsByName("mail")[0].value;
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!filter.test(email)) {
    alert("Please provide a valid email address");
	return false;

   
 }
 return false;
}

function clear1(){
	document.getElementsByName("name")[0].value="";
	document.getElementsByName("telnum")[0].value="";
	document.getElementsByName("mail")[0].value="";
	document.getElementsByName("message")[0].value="";
}
	
		</script>
		// JavaScript Document